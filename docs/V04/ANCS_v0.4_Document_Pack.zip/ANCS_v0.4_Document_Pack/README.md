# ANCS v0.4 文档包

统一需求权威：**ANCS_AI_Native_v0.4.md**。

本版整合原v0.3、用户上传的竞品/架构增量、详尽运营后台与苹果式极简黑白设计。共29章、17个工作流、219项任务、131条需求；原126项任务ID不变，新增93项，显式补充22项旧任务。来源文件的“已实现”不转成当前完成状态。

## 文件

| 文件 | 用途 |
|---|---|
| ANCS_AI_Native_v0.4.md | 全量合并总规范，可单独阅读 |
| ANCS_v0.4_Incremental_Changes.md | 增量摘要、冲突裁决、新增需求/任务与旧任务补充 |
| ANCS_v0.4_Task_Backlog.md | 与总规范§23同源任务，依赖/内容/验收/角色等 |
| ANCS_v0.4_Traceability.md | 与§24同源需求追踪 |
| ANCS_v0.4_Operations_Backoffice.md | 24运营模块、40任务、O0/O1/O2、20业务旅程 |
| ANCS_v0.4_Design_System.md | 全站黑白设计、12任务、D0/D1、12设计旅程 |
| ANCS_v0.4_Design_Tokens.json / .css | 自有token实现参考，不含字体，不代表已集成 |
| ANCS_v0.4_Codex_Start.md | 接手/增量开发指令 |
| task_index.json | 全量任务与需求、基线、变更与状态元数据 |
| DOCUMENT_VALIDATION.md | 本轮文档及色对检查结果；不是应用测试 |
| FILE_MANIFEST.json | 文件hash/大小清单，含来源原件一致性 |
| tools/validate_document_pack.py | 在Python 3中重跑文档结构/依赖/追踪/色对/hash检查 |
| references/ | 原上传方案和v0.3历史原件；不是当前执行入口 |

## 实施原则

保留现有工程，不初始化第二个编辑器／后台。N13安全、N15运营、N16设计为横切任务；阶段号不是串行顺序。当前状态以实际仓库交接为准，保留旧VERIFIED证据并追加v0.4验收。

G0素材内核/G1共同看片/G2三模式与策略/G3专业能力/G4商业与多端，O0/O1/O2运营和D0/D1设计各自验收，不能互相冒充。

本轮只改文档文件，未更改GitHub代码、执行应用测试、调用付费制作API或部署。历史代码基线`2fa881db7a9d024a03b5077f197f7cedbbeea194`继承v0.3，开工重新核对HEAD。

重跑静态校验：`python tools/validate_document_pack.py`。通过不表示真实视频、运营、付款、语音、界面或WCAG全站验收通过。
