#!/usr/bin/env python3
"""Validate the ANCS document pack only, never the application or a Provider.

Usage: python tools/validate_document_pack.py [--self-test] [--json]
No network, dependencies, application writes, paid calls, or repository access.
"""
from __future__ import annotations
import argparse
import collections
import copy
import hashlib
import json
from pathlib import Path
import re
import sys
from typing import Any

ROOT = Path(__file__).resolve().parent.parent

class ValidationError(ValueError):
    pass

def require(condition: bool, message: str) -> None:
    if not condition:
        raise ValidationError(message)

def read_json(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8"))

def validate_graph(tasks: list[dict[str, Any]]) -> list[str]:
    by_id = {task["id"]: task for task in tasks}
    require(len(by_id) == len(tasks), "Duplicate task ID")
    for task in tasks:
        require(len(task["deps"]) == len(set(task["deps"])), f'Duplicate dependency: {task["id"]}')
        for dependency in task["deps"]:
            require(dependency in by_id, f'Missing dependency {dependency} for {task["id"]}')
    done: set[str] = set()
    active: set[str] = set()
    ordered: list[str] = []
    def visit(task_id: str, trail: tuple[str, ...] = ()) -> None:
        require(task_id not in active, "Dependency cycle: " + " -> ".join((*trail, task_id)))
        if task_id in done:
            return
        active.add(task_id)
        for dep in by_id[task_id]["deps"]:
            visit(dep, (*trail, task_id))
        active.remove(task_id)
        done.add(task_id)
        ordered.append(task_id)
    for task_id in by_id:
        visit(task_id)
    return ordered

def luminance(hex_color: str) -> float:
    require(bool(re.fullmatch(r"#[0-9a-fA-F]{6}", hex_color)), f"Invalid color: {hex_color}")
    rgb = [int(hex_color[i:i+2], 16) / 255 for i in (1, 3, 5)]
    linear = [c / 12.92 if c <= 0.04045 else ((c + 0.055) / 1.055) ** 2.4 for c in rgb]
    return sum(c * w for c, w in zip(linear, (0.2126, 0.7152, 0.0722)))

def contrast(fg: str, bg: str) -> float:
    values = sorted((luminance(fg), luminance(bg)))
    return (values[1] + 0.05) / (values[0] + 0.05)

def validate_colors(tokens: dict[str, Any]) -> list[dict[str, Any]]:
    themes = tokens["themes"]
    require(set(themes["light"]) == set(themes["dark"]), "Theme key mismatch")
    results: list[dict[str, Any]] = []
    for theme, values in themes.items():
        for key, color in values.items():
            luminance(color)
            require(color[1:3].upper() == color[3:5].upper() == color[5:7].upper(), f"Non-neutral UI token: {theme}/{key}")
        for pair in tokens["contrastPairs"]:
            ratio = contrast(values[pair["foreground"]], values[pair["background"]])
            require(ratio >= pair["minimum"], f'Contrast failed: {theme} {pair["foreground"]} / {pair["background"]}: {ratio}')
            results.append({"theme": theme, **pair, "ratio": ratio})
    return results

def validate_baseline(tasks: list[dict[str, Any]], baseline: list[dict[str, Any]]) -> None:
    by_id = {t["id"]: t for t in tasks}
    for old in baseline:
        require(old["id"] in by_id, f'Missing original task {old["id"]}')
        current = by_id[old["id"]]
        for field in ("title", "work", "test", "paths", "status"):
            require(current[field] == old[field], f'Original task changed: {old["id"]}/{field}')
        require(set(old["deps"]) <= set(current["deps"]), f'Old dependency removed: {old["id"]}')
        require(set(old["req"]) <= set(current["req"]), f'Old requirement mapping removed: {old["id"]}')

def self_test(index: dict[str, Any], tokens: dict[str, Any]) -> int:
    """Prove the validator rejects duplicate IDs, missing deps, cycles, bad colors."""
    failures = []
    duplicate = copy.deepcopy(index["tasks"])
    duplicate.append(copy.deepcopy(duplicate[0]))
    failures.append(lambda: validate_graph(duplicate))
    missing = copy.deepcopy(index["tasks"])
    missing[0]["deps"].append("N99-99")
    failures.append(lambda: validate_graph(missing))
    cyclic = copy.deepcopy(index["tasks"])
    cyclic[0]["deps"].append(cyclic[0]["id"])
    failures.append(lambda: validate_graph(cyclic))
    bad_colors = copy.deepcopy(tokens)
    bad_colors["themes"]["light"]["ui.fg.primary"] = "#FFFFFF"
    failures.append(lambda: validate_colors(bad_colors))
    rejected = 0
    for fn in failures:
        try:
            fn()
        except ValidationError:
            rejected += 1
    require(rejected == len(failures), "A negative validator fixture incorrectly passed")
    return rejected

def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--self-test", action="store_true")
    parser.add_argument("--json", action="store_true")
    args = parser.parse_args()
    try:
        index = read_json(ROOT / "task_index.json")
        tokens = read_json(ROOT / "ANCS_v0.4_Design_Tokens.json")
        tasks = index["tasks"]
        requirements = index["requirements"]
        counts = index["counts"]
        graph_order = validate_graph(tasks)
        by_id = {t["id"]: t for t in tasks}
        by_req = {r["id"]: r for r in requirements}
        require(len(by_req) == len(requirements), "Duplicate requirement ID")
        require(all(t["status"] == "TODO" for t in tasks), "Initial document claims completed application work")
        require(counts["totalTasks"] == len(tasks) == 219, "Task count mismatch")
        require(counts["totalRequirements"] == len(requirements) == 131, "Requirement count mismatch")
        require(counts["workflows"] == len(index["phases"]) == 17, "Workflow count mismatch")
        require({r["id"] for r in requirements if r["id"].startswith("V03-")} == {f"V03-{i:02}" for i in range(1,69)}, "Baseline requirement IDs lost")
        for task in tasks:
            require(bool(task["req"]), f'Task without requirements: {task["id"]}')
            require(set(task["req"]) <= set(by_req), f'Unknown requirement in {task["id"]}')
        for r in requirements:
            derived = {t["id"] for t in tasks if r["id"] in t["req"]}
            require(bool(derived), f'Uncovered requirement {r["id"]}')
            require(derived == set(r["tasks"]), f'Reverse mapping mismatch {r["id"]}')
        baseline = read_json(ROOT / "references/v03_task_index.json")["tasks"]
        require(len(baseline) == 126, "Baseline task count mismatch")
        validate_baseline(tasks, baseline)
        require(sum(t["introducedIn"] == "0.4" for t in tasks) == counts["newTasks"] == 93, "New task count mismatch")
        require(sum(t.get("amendedIn") == "0.4" and t["introducedIn"] == "0.3" for t in tasks) == counts["amendedBaselineTasks"] == 22, "Amendment count mismatch")
        require(sum(t["phase"] == "N15" for t in tasks) == 40, "Ops task count mismatch")
        require(sum(t["phase"] == "N16" for t in tasks) == 12, "Design task count mismatch")

        master = (ROOT / "ANCS_AI_Native_v0.4.md").read_text(encoding="utf-8")
        anchors = re.findall(r'<a id="([^"]+)"></a>', master)
        require(len(anchors) == len(set(anchors)), "Duplicate anchor in master")
        require({f"s{i:02}" for i in range(1,30)} <= set(anchors), "Missing master section")
        for link in re.findall(r'\]\(#([^\)]+)\)', master):
            require(link in anchors, f"Broken internal link: #{link}")
        require(len(re.findall(r'^### N\d{2}-\d{2} ', master, re.M)) == len(tasks), "Task rendering count mismatch")
        for task in tasks:
            require(f'### {task["id"]} {task["title"]}' in master, f'Missing rendered task {task["id"]}')
        headings = [(int(m.group(1)),m.start()) for m in re.finditer(r'<a id="s(\d{2})"></a>', master)]
        sections = {num: master[start:headings[i+1][1] if i+1 < len(headings) else len(master)] for i,(num,start) in enumerate(headings)}
        for n, filename in ((23,"ANCS_v0.4_Task_Backlog.md"),(24,"ANCS_v0.4_Traceability.md"),(28,"ANCS_v0.4_Operations_Backoffice.md"),(29,"ANCS_v0.4_Design_System.md")):
            independent=(ROOT/filename).read_text(encoding="utf-8")
            require(sections[n].strip() in independent, f"Standalone divergence: {filename}")
        require(len(re.findall(r'^\| OP\d{2} ', sections[28], re.M)) == 24, "Ops module count mismatch")
        require(len(re.findall(r'^\| O-E\d{2} ', sections[28], re.M)) == 20, "Ops journey count mismatch")
        require(len(re.findall(r'^\| D-E\d{2} ', sections[29], re.M)) == 12, "Design journey count mismatch")
        for path in ROOT.glob("*.md"):
            text = path.read_text(encoding="utf-8")
            require(text.count("\ufffd") == 0, f"Replacement character: {path.name}")
            require(len(re.findall(r'^```', text, re.M)) % 2 == 0, f"Unclosed code fence: {path.name}")
        for source in index["sources"]:
            if "file" in source:
                file_path=ROOT/source["file"]
                require(file_path.is_file(), f"Missing original: {file_path}")
                require(hashlib.sha256(file_path.read_bytes()).hexdigest() == source["sha256"], f"Source hash mismatch: {file_path}")
        colors = validate_colors(tokens)
        for key in tokens["themes"]["light"]:
            row=f'| `{key}` | `{tokens["themes"]["light"][key]}` | `{tokens["themes"]["dark"][key]}` |'
            require(row in sections[29], f"Color table divergence: {key}")
        forbidden={".ttf",".otf",".ttc",".woff",".woff2"}
        require(not any(p.suffix.lower() in forbidden for p in ROOT.rglob("*") if p.is_file()), "Font files must not be distributed")
        manifest_path=ROOT/"FILE_MANIFEST.json"
        manifest_state="NOT_YET_CREATED"
        hashed_count=0
        if manifest_path.exists():
            manifest=read_json(manifest_path)
            for row in manifest["files"]:
                path=ROOT/row["path"]
                require(path.is_file(), f'Manifest file missing: {row["path"]}')
                require(path.stat().st_size == row["bytes"], f'Size mismatch: {row["path"]}')
                require(hashlib.sha256(path.read_bytes()).hexdigest() == row["sha256"], f'Hash mismatch: {row["path"]}')
                hashed_count+=1
            manifest_state="PASS"
        negative_count=self_test(index,tokens) if args.self_test else 0
        result={"status":"PASS","scope":"DOCUMENT_AND_SPECIFIED_TOKEN_PAIRS_ONLY","tasks":len(tasks),"requirements":len(requirements),"workflows":len(index["phases"]),"baselineTasksPreserved":len(baseline),"amendedBaselineTasks":counts["amendedBaselineTasks"],"newTasks":counts["newTasks"],"dependencyEdges":sum(len(t["deps"]) for t in tasks),"topologicalNodes":len(graph_order),"requirementsWithoutTasks":0,"brokenInternalLinks":0,"duplicateIds":0,"opsModules":24,"opsJourneys":20,"designJourneys":12,"staticContrastPairs":len(colors),"minimumTextContrast":min(c["ratio"] for c in colors if c["minimum"]==4.5),"minimumControlContrast":min(c["ratio"] for c in colors if c["minimum"]==3),"negativeSelfTestsRejected":negative_count,"manifest":manifest_state,"manifestFiles":hashed_count,"applicationTests":"NOT_RUN","browserTests":"NOT_RUN","providerTests":"NOT_RUN","repositoryWrites":"NONE","colors":colors}
        if args.json:
            print(json.dumps(result,ensure_ascii=False,indent=2))
        else:
            print("PASS: 219 tasks / 131 requirements / 17 workflows; original 126 tasks preserved.")
            print(f"DAG, mappings, chapters, standalone sections, source hashes and {len(colors)} token contrast pairs passed.")
            print(f"Manifest: {manifest_state}; negative self-tests rejected: {negative_count}.")
            print("Application/browser/Provider tests NOT RUN; no repository writes.")
        return 0
    except (ValidationError,KeyError,ValueError,OSError) as exc:
        print(f"FAIL: {exc}",file=sys.stderr)
        return 1

if __name__ == "__main__":
    raise SystemExit(main())
